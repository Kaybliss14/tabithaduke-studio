/**
 * Tabithaduke Studio — main.js
 * Shared across every page (index.html, portfolio.html, services.html,
 * pricing.html, about.html, faq.html, contact.html).
 *
 * Handles: mobile navigation toggle, FAQ accordion, contact form submission.
 * Each init function checks for its own elements first, so it's safe to
 * include this same file on pages that don't have every feature.
 */

document.addEventListener('DOMContentLoaded', function () {
  initMobileNav();
  initFaqAccordion();
  initContactForm();
  initHeroSlider();
  initScrollProgress();
  initScrollReveal();
  initPortfolioFilter();
});

/**
 * Mobile navigation toggle.
 * Shows/hides the primary nav as a stacked list on small screens.
 * Present on every page (shared header).
 */
function initMobileNav() {
  var menuToggle = document.getElementById('menuToggle');
  var primaryNav = document.getElementById('primaryNav');

  if (!menuToggle || !primaryNav) return;

  menuToggle.addEventListener('click', function () {
    var isOpen = primaryNav.classList.contains('nav-open');
    if (isOpen) {
      closeMobileNav();
    } else {
      openMobileNav();
    }
  });

  primaryNav.querySelectorAll('a').forEach(function (link) {
    link.addEventListener('click', function () {
      if (window.innerWidth <= 960) {
        closeMobileNav();
      }
    });
  });

  function openMobileNav() {
    primaryNav.classList.add('nav-open');
    primaryNav.style.display = 'flex';
    primaryNav.style.flexDirection = 'column';
    primaryNav.style.position = 'absolute';
    primaryNav.style.top = '64px';
    primaryNav.style.left = '0';
    primaryNav.style.right = '0';
    primaryNav.style.background = 'rgba(5, 8, 22, 0.97)';
    primaryNav.style.borderBottom = '1px solid var(--card-brd)';
    primaryNav.style.padding = '10px 20px 18px';
    menuToggle.setAttribute('aria-expanded', 'true');
  }

  function closeMobileNav() {
    primaryNav.classList.remove('nav-open');
    primaryNav.style.display = 'none';
    menuToggle.setAttribute('aria-expanded', 'false');
  }
}

/**
 * FAQ accordion.
 * Only present on faq.html (and optionally other pages with a mini-FAQ).
 * Only one item is open at a time.
 */
function initFaqAccordion() {
  var faqButtons = document.querySelectorAll('.faq-q');
  if (!faqButtons.length) return;

  faqButtons.forEach(function (button) {
    button.addEventListener('click', function () {
      var item = button.parentElement;
      var wasOpen = item.classList.contains('open');

      document.querySelectorAll('.faq-item').forEach(function (i) {
        i.classList.remove('open');
        var q = i.querySelector('.faq-q');
        if (q) q.setAttribute('aria-expanded', 'false');
      });

      if (!wasOpen) {
        item.classList.add('open');
        button.setAttribute('aria-expanded', 'true');
      }
    });
  });
}

/**
 * Contact form submission handler.
 * Only present on contact.html.
 * Currently front-end only: shows a confirmation message and resets the form.
 * Replace the TODO block below with a real fetch() call to your backend,
 * form service (e.g. Formspree, Getform), or email API once one is ready.
 */
function initContactForm() {
  var form = document.getElementById('contactForm');
  var note = document.getElementById('contactNote');

  if (!form) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    var honeypot = form.elements['company'];
    if (honeypot && honeypot.value) {
      return; // silently drop likely spam
    }

    // TODO: replace with a real submission, e.g.:
    // fetch('https://your-form-endpoint.example/submit', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify(Object.fromEntries(new FormData(form)))
    // })
    //   .then(function (res) { if (res.ok) showNote(); })
    //   .catch(function (err) { console.error('Form submission failed:', err); });

    showNote();
    form.reset();
  });

  function showNote() {
    if (note) note.classList.add('show');
  }
}

/**
 * Fullscreen hero slider (home page only).
 * Crossfades between full-bleed avatar showcase backgrounds behind the static
 * hero headline/CTA. Auto-advances every 6 seconds, pauses on hover/focus,
 * supports arrow buttons, dot navigation, and left/right arrow keys when
 * the slider is focused. Safely does nothing on pages without #heroSlider.
 */
function initHeroSlider() {
  var slider = document.getElementById('heroSlider');
  if (!slider) return;

  var slides = slider.querySelectorAll('.hero-slide');
  var dots = document.querySelectorAll('#heroDots .carousel-dot');
  var prevBtn = document.getElementById('heroPrev');
  var nextBtn = document.getElementById('heroNext');
  var counter = document.getElementById('heroCounter');
  var tag = document.getElementById('heroSlideTag');
  var headline = document.getElementById('heroHeadline');
  var lede = document.getElementById('heroLede');
  var total = slides.length;
  var current = 0;
  var autoplayMs = 6000;
  var timer = null;

  // Per-slide content for the floating tag chip and the main headline/subheading.
  // Keep these arrays in sync with the .hero-slide markup above (same order).
  // headline/lede accept simple HTML (e.g. a <span class="accent-word"> for emphasis).
  var labels = [
    'Custom Avatar · Featured Render',
    'Character Model · Game-Ready',
    'Custom Commission · Spider Avatar'
  ];
  var headlines = [
    'Custom VRChat Avatars <span class="accent-word">Built for Creators</span>',
    'Professional <span class="accent-word">3D Character Modeling</span>',
    '<span class="accent-word">Custom Avatar</span> Commissions'
  ];
  var ledes = [
    'High quality VRChat avatars designed for streamers, VTubers, roleplayers and virtual communities.',
    'Game-ready characters optimized for VRChat, Unity, Unreal Engine and animation.',
    'Original characters, fan art, anime and realistic avatars with optimized topology and textures.'
  ];

  function pad(n) { return n < 10 ? '0' + n : String(n); }

  function goToSlide(index, isInitial) {
    current = (index + total) % total;

    slides.forEach(function (slide, i) {
      slide.classList.toggle('is-active', i === current);
    });
    dots.forEach(function (dot, i) {
      var isActive = i === current;
      dot.classList.toggle('is-active', isActive);
      dot.setAttribute('aria-selected', String(isActive));
    });
    if (counter) counter.textContent = pad(current + 1) + ' / ' + pad(total);
    if (tag && labels[current]) tag.textContent = labels[current];

    // Fade the headline/subheading out, swap the text, fade back in — the
    // background crossfade timing/animation itself is untouched. Skipped on
    // the initial load so it doesn't fight with the existing hero-enter animation.
    if (isInitial) {
      if (headline && headlines[current]) headline.innerHTML = headlines[current];
      if (lede && ledes[current]) lede.textContent = ledes[current];
      return;
    }
    if (headline && headlines[current]) {
      headline.style.transition = 'opacity 0.35s ease';
      headline.style.opacity = '0';
      window.setTimeout(function () {
        headline.innerHTML = headlines[current];
        headline.style.opacity = '1';
      }, 350);
    }
    if (lede && ledes[current]) {
      lede.style.transition = 'opacity 0.35s ease';
      lede.style.opacity = '0';
      window.setTimeout(function () {
        lede.textContent = ledes[current];
        lede.style.opacity = '1';
      }, 350);
    }
  }

  function next() { goToSlide(current + 1); }
  function prev() { goToSlide(current - 1); }

  function startAutoplay() {
    stopAutoplay();
    timer = window.setInterval(next, autoplayMs);
  }

  function stopAutoplay() {
    if (timer) {
      window.clearInterval(timer);
      timer = null;
    }
  }

  if (nextBtn) nextBtn.addEventListener('click', function () { next(); startAutoplay(); });
  if (prevBtn) prevBtn.addEventListener('click', function () { prev(); startAutoplay(); });

  dots.forEach(function (dot) {
    dot.addEventListener('click', function () {
      var target = parseInt(dot.getAttribute('data-goto'), 10);
      if (!isNaN(target)) {
        goToSlide(target);
        startAutoplay();
      }
    });
  });

  // Pause on hover and keyboard focus so the slider doesn't move while a
  // visitor is reading the hero or interacting with its controls.
  slider.addEventListener('mouseenter', stopAutoplay);
  slider.addEventListener('mouseleave', startAutoplay);
  slider.addEventListener('focusin', stopAutoplay);
  slider.addEventListener('focusout', startAutoplay);

  slider.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowRight') { next(); startAutoplay(); }
    if (e.key === 'ArrowLeft') { prev(); startAutoplay(); }
  });

  goToSlide(0, true);
  startAutoplay();
}

/**
 * Scroll progress bar.
 * Fills the thin bar at the top of the page as the visitor scrolls down.
 * Present in the markup on every page (shared header partial), so this
 * runs everywhere, not just the homepage.
 */
function initScrollProgress() {
  var bar = document.getElementById('scrollProgress');
  if (!bar) return;

  var ticking = false;

  function update() {
    var scrollTop = window.scrollY || document.documentElement.scrollTop;
    var docHeight = document.documentElement.scrollHeight - window.innerHeight;
    var pct = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
    bar.style.width = pct + '%';
    ticking = false;
  }

  window.addEventListener('scroll', function () {
    if (!ticking) {
      window.requestAnimationFrame(update);
      ticking = true;
    }
  }, { passive: true });

  window.addEventListener('resize', update);

  update();
}

/**
 * Scroll-reveal animation.
 * Fades/slides ".reveal" elements into view the first time they enter the
 * viewport. Currently only used on index.html (Featured Portfolio, Services
 * Preview, Why Choose Us, and the closing CTA), but written generically so
 * it's safe to reuse on any future page — it simply does nothing if no
 * ".reveal" elements are present.
 */
function initScrollReveal() {
  var items = document.querySelectorAll('.reveal');
  if (!items.length) return;

  // Respect reduced-motion preference: show everything immediately, no animation.
  var prefersReducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (prefersReducedMotion || !('IntersectionObserver' in window)) {
    items.forEach(function (el) { el.classList.add('is-visible'); });
    return;
  }

  var observer = new IntersectionObserver(function (entries, obs) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });

  items.forEach(function (el) { observer.observe(el); });
}

/**
 * Portfolio category filter (portfolio.html only).
 * Toggles which .avatar-card project cards are visible based on the
 * selected .filter-chip's data-filter value ("all" or a category slug
 * matching a card's data-category attribute). Safely does nothing on
 * pages without a #portfolioFilters element.
 */
function initPortfolioFilter() {
  var filterBar = document.getElementById('portfolioFilters');
  if (!filterBar) return;

  var chips = filterBar.querySelectorAll('.filter-chip');
  var cards = document.querySelectorAll('[data-category]');

  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      chips.forEach(function (c) { c.setAttribute('aria-pressed', 'false'); });
      chip.setAttribute('aria-pressed', 'true');

      var filter = chip.getAttribute('data-filter');
      cards.forEach(function (card) {
        var match = filter === 'all' || card.getAttribute('data-category') === filter;
        card.style.display = match ? '' : 'none';
      });
    });
  });
}
